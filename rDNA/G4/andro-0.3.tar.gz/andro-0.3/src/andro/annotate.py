import re
from Bio.Seq import Seq
from Bio.Align import PairwiseAligner
from .sequtils import Interval
from .rdna import Rdna, Feature, LR, TR, IncompleteRdna
from .find import RdnaUnitFinder, PartialUnitFinder, Gene45sFinder


class RdnaAnnotator:
    def __init__(self, reference: Rdna, k: int, partial: bool):
        self.reference = reference
        self.k = k
        self.partial = partial
        self.finder = RdnaUnitFinder(self.reference, self.k)
        self.partial_finder = PartialUnitFinder(self.reference) if self.partial else None
        self.promoters_annotator = PromotersAnnotator()
        self.tr_annotator = TrAnnotator(self.reference)
        self.lr_annotator = LrAnnotator(self.reference)
        self.ttf1_annotator = Ttf1Annotator()

    def annotate(self, seq: Seq):
        rdnas = self.finder.find(seq)
        if self.partial_finder:
            rdnas.extend(self.partial_finder.find(seq, rdnas))
            rdnas.sort()

        for unit in rdnas:
            if isinstance(unit, Rdna):
                self._annotate_inner(unit)
                yield unit
            elif isinstance(unit, IncompleteRdna):
                self._annotate_incomplete_inner(unit)
                yield unit

    def _annotate_inner(self, unit: Rdna):
        self.tr_annotator.annotate(unit)
        self.lr_annotator.annotate(unit)

        unit.spacer_promoter = self.promoters_annotator.annotate(unit, self.reference.spacer_promoter)
        unit.upstream_control_element = self.promoters_annotator.annotate(unit, self.reference.upstream_control_element)
        unit.main_promoter = self.promoters_annotator.annotate(unit, self.reference.main_promoter)
        unit.others = self.ttf1_annotator.annotate(unit)


    def _annotate_incomplete_inner(self, unit: IncompleteRdna):
        unit.color = self.reference.color
        self._annotate_incomplete_gene45s(unit)
        if unit.prefix:
            unit.spacer_promoter = self.promoters_annotator.annotate(unit, self.reference.spacer_promoter)
            unit.upstream_control_element = self.promoters_annotator.annotate(unit, self.reference.upstream_control_element)
            unit.main_promoter = self.promoters_annotator.annotate(unit, self.reference.main_promoter)
        else:
            if unit.gene45s is not None and unit.end - unit.gene45s.end > 0:
                unit.igs = Feature(unit.gene45s.end, unit.end, unit.base, self.reference.igs.name)
            else:
                unit.igs = Feature(unit.start, unit.end, unit.base, self.reference.igs.name)
            unit.igs.color = self.reference.igs.color
            self.tr_annotator.annotate(unit)
            self.lr_annotator.annotate(unit)
        unit.others = self.ttf1_annotator.annotate(unit)

    def _annotate_incomplete_gene45s(self, unit: IncompleteRdna):
        finder = Gene45sFinder(self.reference, self.k)
        gene = finder.find_incomplete(unit)
        if gene is None:
            return
        gene += unit.start
        gene.color = self.reference.gene45s.color
        for attr in ["ets5", "gene18s", "its1", "gene58s", "its2", "gene28s", "ets3"]:
            feature = getattr(gene, attr)
            if feature is None:
                continue
            feature += unit.start
            feature.color = getattr(self.reference.gene45s, attr).color
            setattr(gene, attr, feature)
        unit.gene45s = gene


class PromotersAnnotator:
    def __init__(self):
        pass

    def annotate(self, unit: Rdna | IncompleteRdna, needle: Feature):
        if isinstance(unit, Rdna) or (isinstance(unit, IncompleteRdna) and unit.gene45s is not None):
            haystack = unit.base[unit.start : unit.gene45s.start + 500]
        else:
            haystack = unit.seq
        if len(haystack) == 0:
            return
        aligner = PairwiseAligner(scoring="blastn", mode='local')
        alignment = aligner.align(haystack, needle.seq)[0]
        counts = alignment.counts()
        if counts.identities + counts.gaps < 0.6 * len(needle):
            return

        coordinates = alignment.coordinates[0]
        start, end = unit.start + int(coordinates[0]), unit.start + int(coordinates[-1])
        return Feature(start, end, unit.base, needle.name, needle.color)    


class Ttf1Annotator:
    PATTERN = re.compile(r"GGGTCGACC[AG]G")
    COLOR = "#B15928"

    def annotate(self, unit: Rdna | IncompleteRdna) -> list[Feature]:
        result = []
        haystack = str(unit.seq.seq)
        for match in self.PATTERN.finditer(haystack):
            result.append(
                Feature(
                    unit.start + match.start(),
                    unit.start + match.end(),
                    unit.base,
                    "TTF1",
                    self.COLOR,
                )
            )
        return result


class TrAnnotator:
    def __init__(self, reference: Rdna):
        self.reference = reference

    def annotate(self, unit: Rdna | IncompleteRdna):
        needle = self.reference.igs.tr[0]
        if isinstance(unit, Rdna) or (isinstance(unit, IncompleteRdna) and unit.gene45s is not None):
            start = unit.gene45s.end
        else:
            start = unit.start
        unit.igs.tr = self._find_common(unit, needle, start, start + 4000)

    def _find_common(self, unit: Rdna, needle: Feature, start: int, end: int) -> list[Feature]:
        aligner = PairwiseAligner(scoring="blastn", mode='local')
        haystack = unit.igs.base[start : end]
        alignment = aligner.align(haystack, needle.seq)
        if len(alignment) == 0:
            return []
        alignment = alignment[0]
        counts = alignment.counts()
        if counts.identities < 0.5 * len(needle.seq):
            return []

        coordinates = alignment.coordinates[0]
        feature = Feature(start + int(coordinates[0]), start + int(coordinates[-1]), unit.igs.base, needle.name, needle.color)
        mid = TR(feature)
        back = self._find_next(unit.igs.base, needle, mid.end, True)
        front = self._find_next(unit.igs.base, needle, mid.start, False)
        repeats = front + [mid] + back

        self._refine_repeats(repeats)
        return repeats


    def _refine_repeats(self, features: list[Feature]):
        if len(features) < 2:
            return

        base = features[0].base
        if any(feature.base is not base for feature in features[1:]):
            raise ValueError("all repeat features must belong to the same base sequence")

        self._refine_edge(features, True)
        self._refine_edge(features, False)
        self._refine_gap(features)

    def _refine_edge(self, features: list[Feature], front: bool) -> None:
        seq = features[0].base
        aligner = PairwiseAligner(scoring="blastn", mode='local')
        starts, ends = [], []
        if front:
            edge = features[0].start
            gaps = [(features[i - 1].end, features[i].mid) for i in range(1, len(features))]
        else:
            edge = features[-1].end
            gaps = [(features[i - 1].mid, features[i].start) for i in range(1, len(features))]

        for start, end in gaps:
            length = max((end - start), 25)
            gap = seq[max(start - length, 0) : end + length]
            extended = seq[max(edge - length, 0) : min(edge + length, len(seq))]
            if len(gap) == 0 or len(extended) == 0:
                continue
            alignment = aligner.align(extended, gap)
            if len(alignment) == 0:
                continue

            coordinates = alignment[0].coordinates[0]
            start_alg, end_alg = int(coordinates[0]), int(coordinates[-1])
            starts.append(start_alg + max(edge - length, 0))
            ends.append(end_alg + max(edge - length, 0))

        if front:
            tmp = [(starts.count(start), start) for start in set(starts)]
            tmp.sort(key=lambda x: (x[0], -x[1]), reverse=True)
            features[0].start = min(features[0].start, tmp[0][1])
        else:
            tmp = [(ends.count(end), end) for end in set(ends)]
            tmp.sort(key=lambda x: (x[0], -x[1]), reverse=True)
            features[-1].end = max(features[-1].end, tmp[-1][1])

    def _refine_gap(self, features: list[Feature]):
        first = features[0].seq
        base = features[0].base
        aligner = PairwiseAligner(scoring="blastn", mode='local')
        #refine starts
        for i in range(1, len(features)):
            if features[i].end - features[i - 1].end <= 0:
                continue
            alignment = aligner.align(base[features[i - 1].end : features[i].end], first)[0]
            coordinates = alignment.coordinates[0]
            start = int(coordinates[0])
            features[i].start = min(features[i].start, features[i - 1].end + start)

        #refine ends
        for i in range(len(features) - 1):
            best_end = features[i].end
            best_score = 0
            for edge in range(features[i].end, features[i + 1].start + 1):
                score = edge - features[i + 1].start
                extended = base[features[i].start : edge]
                for j in range(len(features)):
                    if i == j:
                        continue
                    if j != len(features) - 1:
                        score += aligner.score(extended, base[features[j].start: features[j + 1].start])
                    else:
                        score += aligner.score(extended, features[j].seq)
                if score > best_score:
                    best_score = score
                    best_end = edge

            features[i].end = best_end

            # propagate information downstream
            for j in range(i + 1, len(features) - 1):
                alignment = aligner.align(base[features[j].start : features[j + 1].start], features[i].seq)[0]
                coordinates = alignment.coordinates[0]
                end = int(coordinates[-1])
                features[j].end = max(features[j].end, features[j].start + end)

    def _find_next(self, haystack: Seq, needle: Feature, start: int, forward: bool) -> list[Feature]:
        start = max(start,0)
        aligner = PairwiseAligner(scoring="blastn", mode='local')
        direction = 1 if forward else -1
        result = []

        while 0 < start + direction * len(needle) < len(haystack):
            if forward:
                subhay = haystack[start:min(len(haystack), start + int(len(needle) * 1.5))]
            else:
                subhay = haystack[max(0, start - int(len(needle) * 1.5)):start]
            if subhay.count("N") == len(subhay):
                break
            alignments = aligner.align(subhay, needle.seq)
            alignment = alignments[0]

            counts = alignment.counts()
            alg_length = counts.identities + counts.mismatches + counts.gaps

            if counts.identities < 0.8 * alg_length or alg_length < 0.5 * len(needle):
                break

            coordinates = alignment.coordinates[0]
            s, e = int(coordinates[0]), int(coordinates[-1])
            if forward and s > 0.5 * len(needle):
                break
            elif not forward and len(needle) - e > 0.5 * len(needle):
                break
            else:
                if forward:
                    result.append(TR(Feature(start + s, start + e, haystack, needle.name, needle.color)))
                    start += e
                else:
                    true_start = max(0, start - int(len(needle) * 1.5))
                    result.insert(0, TR(Feature(true_start + s, true_start + e, haystack, needle.name, needle.color)))
                    start -= e - s
        return result


class LrAnnotator:
    def __init__(self, reference: Rdna):
        self.reference = reference
        self._prefix, self._ct, self._suffix = self._split_ref()

    def _split_ref(self):
        lr = self.reference.igs.lr[0]
        prefix = lr.base[lr.start : lr.sat.start]
        ct = lr.base[lr.sat.start : lr.sat.end]
        suffix = lr.base[lr.sat.end : lr.end]
        return prefix, ct, suffix

    def annotate(self, unit: Rdna):
        lrs = self._find(unit)

        for repeat in lrs:
            repeat += unit.start
            repeat.sat += unit.start

        unit.igs.lr = lrs

    def _find(self, unit: Rdna) -> list[LR]:
        needle = self.reference.igs.lr[0]
        mid = self._find_single(unit, needle, unit.igs.start - unit.start, unit.end - unit.start)
        if mid is None:
            return []
        front, back = [], []
        lr = mid

        while lr is not None:
            back.append(lr)
            lr = self._find_single(unit, needle, lr.end, lr.end + round(1.2 * len(needle)))

        lr = mid
        while lr is not None:
            front.insert(0, lr)
            lr = self._find_single(unit, needle, lr.start - round(1.2 * len(needle)), lr.start)
        front.pop()

        return front + back


    def _find_single(self, unit: Rdna, needle: Feature, start: int, end: int) -> LR | None:
        start = max(start, 0)
        guess = self._find_ct_rich(unit, start, end)
        if guess is None:
            return None

        aligner = PairwiseAligner(scoring="blastn", mode='local')
        real_start, real_end = guess.start, guess.end
        extended = False

        find_start = max(start, guess.start - round(1.2 * len(self._prefix)))
        haystack = unit.seq[find_start : guess.start]
        if len(haystack) > 0:
            alignment = aligner.align(haystack, self._prefix)[0]
            counts = alignment.counts()
            if counts.identities > 0.6 * len(self._prefix):
                coordinates = alignment.coordinates[0]
                extended = True
                real_start = find_start + int(coordinates[0])

        find_start = max(start, guess.end - round(0.8 * len(self._suffix)))
        find_end = min(end, guess.end + round(1.2 * len(self._suffix)))
        haystack = unit.seq[find_start : find_end]
        if len(haystack) > 0:
            alignment = aligner.align(haystack, self._suffix)[0]
            counts = alignment.counts()
            if counts.identities > 0.7 * len(self._suffix):
                extended = True
                coordinates = alignment.coordinates[0]
                real_end = find_start + int(coordinates[-1])

        if not extended:
            return None
        lr = Feature(real_start, real_end, unit.base, needle.name, needle.color)
        return LR(lr, guess)

    def _find_ct_rich(self, unit: Rdna, start: int, end: int) -> Feature | None:
        ct_rich = self._score_ct_rich(unit.seq[start:end])
        if len(ct_rich) == 0:
            return None
        best = ct_rich[0]

        loc_start, loc_end = start + best.start, start + best.end
        seq = unit.seq[loc_start : loc_end]
        strseq = str(seq.seq)

        best = self._score_ct_rich(Seq(strseq[::-1]))
        if len(best) == 0:
            return None
        best = best[0]
        name = self.reference.igs.lr[0].sat.name
        color = self.reference.igs.lr[0].sat.color
        feat = Feature(loc_end - best.end, loc_end - best.start, unit.base, name, color)
        return feat


    def _score_ct_rich(self, seq: Seq) -> list[Interval]:
        score = 0
        start = None
        result = []
        error = 0
        region_score = 0

        for i, base in enumerate(seq):
            if base in "CT":
                if score != 0:
                    error //= 2
                else:
                    error = 0
                score += 1
            else:
                score = max(0, score - 2 ** error)
                error += 1
            region_score = max(region_score, score)

            if score > 0 and start is None:
                start = i
            elif score <= region_score // 2 and start is not None:
                result.append((region_score, Interval(start, i)))
                region_score = 0
                error = 0
                start = None

        if start is not None:
            result.append((region_score, Interval(start, len(seq))))
        result.sort(reverse=True)

        return [interval for _, interval in result]
