import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon, Patch
import numpy as np
from .sequtils import Interval, KmerIndex
from pathlib import Path
from .rdna import Feature, Rdna


class Dotplot:
    PLOT_LEFT = 0.16
    PLOT_BOTTOM = 0.24
    PLOT_RIGHT = 0.72
    PLOT_TOP = 0.80
    LEGEND_X = 0.75
    LEGEND_Y = 0.96

    def __init__(self, reference: Rdna, k: int, output_dir: Path, mode: str) -> None:
        self.reference = reference
        self.k = k
        self.output_dir = output_dir
        self.mode = mode

    def process(self, unit: Rdna) -> None:
        if self.mode == "self":
            self._dotplot(unit, unit)
        elif self.mode == "ref":
            self._dotplot(unit, self.reference)


    def _dotplot(self, xrdna: Rdna, yrdna: Rdna):
        pairs = Dotplot.create_pairs(KmerIndex(xrdna.seq, self.k), KmerIndex(yrdna.seq, self.k))
        fig = plt.figure(figsize=(7, 7))
        ax = fig.add_axes([
            self.PLOT_LEFT,
            self.PLOT_BOTTOM,
            self.PLOT_RIGHT - self.PLOT_LEFT,
            self.PLOT_TOP - self.PLOT_BOTTOM,
        ])
        if pairs:
            data = np.array(pairs)
            ax.scatter(data[:, 0], data[:, 1], marker=".", s=0.3, linewidths=0, alpha=1, color='black')

        legend = []

        xgene45s = getattr(xrdna, "gene45s", None)
        ygene45s = getattr(yrdna, "gene45s", None)
        xigs = getattr(xrdna, "igs", None)
        yigs = getattr(yrdna, "igs", None)

        self._draw_single_rec(xrdna, yrdna, xgene45s, ygene45s, legend)
        self._draw_single_rec(xrdna, yrdna, self._feature_attr(xgene45s, "gene18s"), self._feature_attr(ygene45s, "gene18s"), legend)
        self._draw_single_rec(xrdna, yrdna, self._feature_attr(xgene45s, "gene58s"), self._feature_attr(ygene45s, "gene58s"), legend)
        self._draw_single_rec(xrdna, yrdna, self._feature_attr(xgene45s, "gene28s"), self._feature_attr(ygene45s, "gene28s"), legend)

        self._draw_array(xrdna, yrdna, self._feature_attr(xigs, "tr", []), self._feature_attr(yigs, "tr", []), legend)
        self._draw_array(xrdna, yrdna, self._feature_attr(xigs, "lr", []), self._feature_attr(yigs, "lr", []), legend)

        yct_sat = [lr.sat for lr in self._feature_attr(yigs, "lr", []) if lr.sat is not None]
        xct_sat = [lr.sat for lr in self._feature_attr(xigs, "lr", []) if lr.sat is not None]
        self._draw_array(xrdna, yrdna, xct_sat, yct_sat, legend)

        ax.set_xlim(0, len(xrdna))
        ax.set_ylim(0, len(yrdna))
        ax.set_aspect("equal", adjustable="box")
        ax.set_anchor("W")
        xlabel = f"{xrdna.seq.name}:{xrdna.start}-{xrdna.end}"
        ylabel = f"{yrdna.seq.name}:{yrdna.start}-{yrdna.end}"
        self._place_axis_labels(ax, fig, xlabel, ylabel)
        if len(legend) > 0:
            fig.legend(
                handles=legend,
                loc='upper left',
                bbox_to_anchor=(self.LEGEND_X, self.LEGEND_Y),
                bbox_transform=fig.transFigure,
                borderaxespad=0.0,
            )
        name = f"{xrdna.seq.name}_{xrdna.start}-{xrdna.end}.png"
        plt.savefig(Path.joinpath(self.output_dir, name), dpi=1000)
        #plt.show()
        plt.close()


    def _feature_attr(self, feature, attr: str, default=None):
        if feature is None:
            return default
        return getattr(feature, attr, default)

    def _place_axis_labels(self, ax, fig, xlabel: str, ylabel: str) -> None:
        ax.set_xlabel(xlabel, loc="center")
        ax.set_ylabel(ylabel, loc="center")

        fig.canvas.draw()
        renderer = fig.canvas.get_renderer()
        axis_bbox = ax.get_window_extent(renderer)
        xlabel_bbox = ax.xaxis.label.get_window_extent(renderer)
        ylabel_bbox = ax.yaxis.label.get_window_extent(renderer)

        if xlabel_bbox.width > axis_bbox.width:
            ax.set_xlabel(xlabel, loc="left")
        if ylabel_bbox.height > axis_bbox.height:
            ax.set_ylabel(ylabel, loc="bottom")

    def create_pairs(xindex: KmerIndex, yindex: KmerIndex):
        pairs = []

        for kmer, positions1 in xindex.items():
            if kmer not in yindex:
                continue

            positions2 = yindex[kmer]
            for p1 in positions1:
                for p2 in positions2:
                    pairs.append((p1, p2))

        return pairs

    def _draw_rectangle(self, xint: Interval, yint: Interval, name, color):
        verts = [(xint.start, yint.start), (xint.start, yint.end), (xint.end, yint.end), (xint.end, yint.start)]
        poly = Polygon(verts, closed=True, lw=0, facecolor=color, alpha=0.3, label=name)
        edge = Polygon(verts, closed=True, lw=0.2, fill=False, edgecolor="grey", alpha=1, label=name)
        plt.gca().add_patch(poly)
        plt.gca().add_patch(edge)



    def _draw_single_rec(self, xrdna: Rdna, yrdna: Rdna, xfeat: Feature, yfeat: Feature, legend):
        if xfeat is None or yfeat is None:
            return
        xinterval = Interval(xfeat.start - xrdna.start, xfeat.end - xrdna.start)
        yinterval = Interval(yfeat.start - yrdna.start, yfeat.end - yrdna.start)
        self._draw_rectangle(xinterval, yinterval, xfeat.name, xfeat.color)
        legend.append(Patch(facecolor=xfeat.color, label=xfeat.name, alpha=0.3))


    def _draw_array(self, xrdna: Rdna, yrdna: Rdna, xfeats: list[Feature], yfeats: list[Feature], legend):
        if not xfeats or not yfeats:
            return

        name = xfeats[0].name
        for xfeat in xfeats:
            for yfeat in yfeats:
                xinterval = Interval(xfeat.start - xrdna.start, xfeat.end - xrdna.start)
                yinterval = Interval(yfeat.start - yrdna.start, yfeat.end - yrdna.start)
                self._draw_rectangle(xinterval, yinterval, name, xfeat.color)
        legend.append(Patch(facecolor=xfeat.color, label=name, alpha=0.3))
