import argparse
import os
import sys
from Bio import SeqIO
from . import __version__
from .annotate import RdnaAnnotator
from .bed import RdnaBedPrinter
from .reference import load_reference
from pathlib import Path



def multi_record_fasta(path):
    """Turn a FASTA file into an iterator of SeqRecord."""
    try:
        return SeqIO.parse(path, "fasta")
    except FileNotFoundError:
        raise argparse.ArgumentTypeError(f"No such file: {path!r}")
    except Exception as e:
        raise argparse.ArgumentTypeError(e)


def existing_dir(path: str) -> Path:
    p = Path(path)
    if not p.exists():
        raise argparse.ArgumentTypeError(f"directory does not exist: {path}")
    if not p.is_dir():
        raise argparse.ArgumentTypeError(f"not a directory: {path}")
    return p


def kmer_size(value):
    try:
        ivalue = int(value)
    except ValueError:
        raise argparse.ArgumentTypeError("kmer size must be integer")
    if not 5 <= ivalue <= 20:
        raise argparse.ArgumentTypeError(f"kmer size must be between 5 and 20, got {ivalue}")
    return ivalue


def init_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="andro",
        description="Find and annotate rDNA in FASTA sequence.\nBy default only units containing 45S region are reported",
        epilog=(
            "This software is provided as-is, without warranty.\n"
            "Contact and issue reports: https://github.com/dmelkovic/andro"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    parser.add_argument(
        "-V", "--version",
        action="version",
        version=f"{__version__}",
    )

    parser.add_argument(
        "input",
        type=multi_record_fasta,
        metavar="file",
        help="input sequence file in FASTA format"
    )

    parser.add_argument(
        "-k", "--kmer",
        type=kmer_size,
        dest="kmer",
        metavar="num",
        default=11,
        help="k-mer size for sequence analysis (5-20)"
    )

    parser.add_argument(
        "-o", "--output",
        type=argparse.FileType("w"),
        metavar="file",
        default=sys.stdout,
        help="write results to file in BED format",
    )

    parser.add_argument(
        "-p", "--plot",
        choices=("self", "ref"),
        help="generate dotplot against itself or against KY962518-ROT reference"
    )

    parser.add_argument(
        "-d", "--dir",
        type=existing_dir,
        dest="output_dir",
        metavar="dir",
        default=Path.cwd(),
        help="directory to store dotplot images"
    )

    parser.add_argument(
        "--partial",
        action="store_true",
        default=False,
        help="report incomplete rDNA units that do not contain a complete 45S region",
    )

    return parser


def _record_name(record) -> str:
    return getattr(record, "id", None) or getattr(record, "name", None) or "<unknown>"


def _report_crash(error: Exception) -> int:
    print(f"{type(error).__name__}: {error}", file=sys.stderr)
    print("You can report issues on https://github.com/dmelkovic/andro", file=sys.stderr)
    return 1


def main():
    error = False
    try:
        parser = init_parser()
        args = parser.parse_args()

        reference = load_reference()
        annotator = RdnaAnnotator(reference, args.kmer, args.partial)
        printer = RdnaBedPrinter(args.output)
        dotplot = None
        if args.plot is not None:
            from .dotplot import Dotplot
            dotplot = Dotplot(reference, args.kmer, args.output_dir, args.plot)

        for rec in args.input:
            try:
                for unit in annotator.annotate(rec):
                    printer.process(unit)
                    if dotplot is not None:
                        dotplot.process(unit)
            except Exception as e:
                error = True
                print(f"Error while processing record: {_record_name(rec)}", file=sys.stderr)
                raise
    except KeyboardInterrupt:
        return 130
    except MemoryError:
        print("Out of memory", file=sys.stderr)
        return 1
    except Exception as e:
        return _report_crash(e)
    if error:
        return _report_crash(e)
    return 0
