from importlib.resources import files

from Bio import SeqIO

from .rdna import Feature, Gene45s, Igs, LR, Rdna


def load_reference(path=None) -> Rdna:
    if path is None:
        path = files("andro.ref").joinpath("KY962518-ROT.fa")

    seq = SeqIO.read(path, "fasta")

    ets5 = Feature(3744, 7400, seq, "5_ETS")
    gene18s = Feature(7401, 9269, seq, "18S")
    gene58s = Feature(10340, 10496, seq, "5.8S")
    gene28s = Feature(11664, 16714, seq, "28S")
    ets3 = Feature(16715, 17075, seq, "3_ETS")

    gene45s = Gene45s(ets5, gene18s, gene58s, gene28s, ets3)

    igs = Igs(gene45s.end, len(seq), seq)
    igs.tr = [
        Feature(17237, 17922, seq, "TR"),
        Feature(17923, 18609, seq, "TR"),
        Feature(18610, 19295, seq, "TR"),
    ]
    igs.lr = [
        LR(Feature(24383, 28825, seq, "LR"), Feature(25888, 28563, seq, "CT_sat")),
        LR(Feature(28826, 33267, seq, "LR"), Feature(30317, 33099, seq, "CT_sat")),
    ]

    rdna = Rdna(gene45s)
    rdna.start = 0
    rdna.end = len(seq)
    rdna.igs = igs

    rdna.spacer_promoter = Feature(2887, 3071, seq, "spacer_promoter")
    rdna.upstream_control_element = Feature(3558, 3693, seq, "upstream_control_element")
    rdna.main_promoter = Feature(3432, 3824, seq, "main_promoter")

    set_colors(rdna)

    return rdna


def set_colors(unit: Rdna):
    unit.color = "#66C2A5"
    unit.main_promoter.color = "#E78AC3"
    unit.spacer_promoter.color = "#FC8D62"
    unit.upstream_control_element.color = "#8DA0CB"

    unit.gene45s.color = "#FFB2EC"
    unit.gene45s.ets5.color = "#FFD92F"
    unit.gene45s.gene18s.color = "#32F1AB"
    unit.gene45s.its1.color = "#1F78B4"
    unit.gene45s.gene58s.color = "#BE7800"
    unit.gene45s.its2.color = "#9E9E9E"
    unit.gene45s.gene28s.color = "#33A02C"
    unit.gene45s.ets3.color = "#FB8072"

    unit.igs.color = "#E7CD8A"
    for lr in unit.igs.lr:
        lr.color = "#3F8BD6"
        lr.sat.color = "#63FF63"
    for tr in unit.igs.tr:
        tr.color = "#E06666"
