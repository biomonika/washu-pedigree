import ahocorasick
from Bio.Align import PairwiseAligner
from Bio.Seq import Seq
from collections import Counter
from .sequtils import KmerIndex, Interval
from .rdna import Rdna, Igs, Feature, Gene45s, IncompleteRdna, IncompleteGene45s
import numpy as np
import mappy


class QuickFinder:
    """
    This was heavily inspired by code from
    https://github.com/JiaShun-Xiao/BLAST-bioinfor-tool/
    """
    ANCHOR_RATIO = 0.05
    MATCH_RATIO = 0.7

    def __init__(self, reference: Feature, k: int) -> None:
        self._index = KmerIndex(reference.seq, k)
        self.k = k
        self._automaton = ahocorasick.Automaton()
        self._aligner = PairwiseAligner(scoring="blastn", mode='local')
        self.reference = reference

        for kmer in self._index:
            self._automaton.add_word(str(kmer), str(kmer))
        self._automaton.make_automaton()

    def _find_hits(self, seq: Seq) -> list[int]:
        positions = {}
        for end_idx, kmer in self._automaton.iter(str(seq.seq)):
            start_idx = end_idx - len(kmer) + 1
            positions.setdefault(kmer, []).append(start_idx)

        offsets = Counter()
        kmers_count = len(self.reference) - self.k + 1
        for i in range(kmers_count):
            kmer = str(self.reference.seq[i:i+self.k].seq)
            for pos in positions.get(kmer, []):
                offsets[pos - i] += 1

        hits = []
        last = None
        for pos, count in offsets.items():
            if count < kmers_count * self.ANCHOR_RATIO:
                continue
            if last is not None and last + len(self.reference) > pos:
                continue
            hits.append(pos)
            last = pos

        return hits

    def _find(self, seq: Seq) -> list[Feature]:
        hits = self._find_hits(seq)
        features = []

        for hit in hits:
            start = max(0, hit - self.k)
            end = min(len(seq), start + len(self.reference) + self.k)
            region = seq[start:end]

            alignment = self._aligner.align(region, self.reference.seq)[0]
            counts = alignment.counts()
            if counts.identities < self.MATCH_RATIO * len(self.reference):
                continue

            coordinates = alignment.coordinates[0]
            feature = Feature(start + int(coordinates[0]), start + int(coordinates[-1]), seq, self.reference.name)
            features.append(feature)

        return features

    def find(self, seq: Seq, start: int | None = None, end: int | None = None) -> list[Feature]:
        start = 0 if start is None else max(0, int(start))
        end = len(seq) if end is None else min(len(seq), int(end))

        subseq = seq[start:end]
        features = self._find(subseq)
        for feature in features:
            feature.start = start + feature.start
            feature.end = start + feature.end
            feature.base = seq
            feature.color = self.reference.color
        return features


class Gene45sFinder:
    def __init__(self, reference: Rdna, k: int):
        self.reference = reference
        self.k = k

        self.finder5ets = QuickFinder(self.reference.gene45s.ets5, self.k)
        self.finder18s = QuickFinder(self.reference.gene45s.gene18s, self.k)
        self.finder58s = QuickFinder(self.reference.gene45s.gene58s, self.k)
        self.finder28s = QuickFinder(self.reference.gene45s.gene28s, self.k)
        self.finder3ets = QuickFinder(self.reference.gene45s.ets3, self.k)

        self._aligner = PairwiseAligner(scoring="blastn", mode='local')

    def find(self, seq: Seq) -> list[Gene45s]:
        clusters = []
        genes58s = self.finder58s.find(seq)
        window = len(self.reference) // 2

        for gene58s in genes58s:
            genes18s = self.finder18s.find(seq, gene58s.start - window, gene58s.start)
            genes28s = self.finder28s.find(seq, gene58s.end, gene58s.end + window)
            if len(genes18s) == 1 and len(genes28s) == 1:
                ets5 = self.finder5ets.find(seq, genes18s[0].start - 1.5 * len(self.reference.gene45s.ets5), genes18s[0].start)
                ets3 = self.finder3ets.find(seq, genes28s[0].end, genes28s[0].end + 1.5 * len(self.reference.gene45s.ets3))
                if len(ets5) == 1 and len(ets3) == 1:
                    ets5[0].end = genes18s[0].start
                    ets3[0].start = genes28s[0].end
                    new = Gene45s(ets5[0], genes18s[0], gene58s, genes28s[0], ets3[0])
                    new.color = self.reference.gene45s.color
                    new.its1.color = self.reference.gene45s.its1.color
                    new.its2.color = self.reference.gene45s.its2.color
                    clusters.append(new)

        return clusters
    
    def find_incomplete(self, unit: IncompleteRdna) -> IncompleteGene45s:
        seq = unit.seq
        finders = [self.finder5ets, self.finder18s, self.finder58s, self.finder28s, self.finder3ets]
        segments = [None] * len(finders)
        if unit.prefix:
            start = 0
            for i in range(len(finders)):
                segments[i] = self._find_incomplete_using_quick(seq, finders[i], start)
                if segments[i] is not None:
                    start = segments[i].end
        else:
            end = len(seq)
            for i in range(len(finders) - 1, -1, -1):
                segments[i] = self._find_incomplete_using_quick(seq, finders[i], 0, end)
                if segments[i] is not None:
                    end = segments[i].start
        
        its1 = self._find_its1_helper(seq, segments)
        its2 = self._find_its2_helper(seq, segments)
        final_segments = [segments[0], segments[1], its1, segments[2], its2, segments[3], segments[4]]
        
        self._find_terminal_fragment(seq, final_segments)

        start, end = len(seq), 0
        is_partial = False
        for segment in final_segments:
            if segment is None:
                continue
            is_partial = True
            start = min(segment.start, start)
            end = max(segment.end, end)
        
        if not is_partial:
            return None
        gene = IncompleteGene45s(start, end, seq)
        gene.ets5 = final_segments[0]
        gene.gene18s = final_segments[1]
        gene.its1 = final_segments[2]
        gene.gene58s = final_segments[3]
        gene.its2 = final_segments[4]
        gene.gene28s = final_segments[5]
        gene.ets3 = final_segments[6]

        return gene


    def _find_its1_helper(self, seq: Seq, segments) -> Feature | None:
        if segments[1] is None and segments[2] is None:
            return None
        if segments[1] is not None and segments[2] is not None:
            return Feature(segments[1].end, segments[2].start, seq, self.reference.gene45s.its1.name)

        offset = 0
        if segments[1] is not None:
            offset = segments[1].end
            haystack = seq[offset:]
        else:
            haystack = seq[:segments[2].start]

        if len(haystack) == 0:
            return None

        alignment = self._aligner.align(haystack, self.reference.gene45s.its1.seq)
        if len(alignment) == 0:
            return None
        alignment = alignment[0]
        counts = alignment.counts()
        if counts.identities < 0.8 * len(self.reference.gene45s.its1):
            return None

        coordinates = alignment.coordinates[0]
        return Feature(offset + int(coordinates[0]), offset + int(coordinates[-1]), seq, self.reference.gene45s.its1.name)


    def _find_its2_helper(self, seq: Seq, segments) -> Feature | None:
        if segments[2] is None and segments[3] is None:
            return None
        if segments[2] is not None and segments[3] is not None:
            return Feature(segments[2].end, segments[3].start, seq, self.reference.gene45s.its2.name)

        offset = 0
        if segments[2] is not None:
            offset = segments[2].end
            haystack = seq[offset:]
        else:
            haystack = seq[:segments[3].start]

        if len(haystack) == 0:
            return None
        alignment = self._aligner.align(haystack, self.reference.gene45s.its2.seq)
        if len(alignment) == 0:
            return None
        alignment = alignment[0]
        counts = alignment.counts()
        if counts.identities < 0.8 * len(self.reference.gene45s.its2):
            return None

        coordinates = alignment.coordinates[0]
        return Feature(offset + int(coordinates[0]), offset + int(coordinates[-1]), seq, self.reference.gene45s.its2.name)
        


    def _find_incomplete_using_quick(self, seq: Seq,
                                finder, start=None, end=None) -> Feature | None:
        if start is None:
            start = 0
        if end is None:
            end = len(seq)
        found = finder.find(seq, start, end)
        if len(found) == 1:
            return found[0]
        return None
    
    def _find_terminal_fragment(self, seq: Seq, segments: list[Feature | None]) -> None:
        references = [
            self.reference.gene45s.ets5,
            self.reference.gene45s.gene18s,
            self.reference.gene45s.its1,
            self.reference.gene45s.gene58s,
            self.reference.gene45s.its2,
            self.reference.gene45s.gene28s,
            self.reference.gene45s.ets3,
        ]
        found = [i for i, segment in enumerate(segments) if segment is not None]
        if not found:
            return

        first = found[0]
        if first > 0:
            feat = self._find_terminal_fragment_helper(seq, references[first - 1], 0, segments[first].start)
            if feat is not None:
                segments[first - 1] = feat

        last = found[-1]
        if last < len(segments) - 1:
            feat = self._find_terminal_fragment_helper(seq, references[last + 1], segments[last].end)
            if feat is not None:
                segments[last + 1] = feat


    def _find_terminal_fragment_helper(self, seq: Seq, reference: Feature, start: int, end: int | None = None) -> Feature | None:
        if end is None:
            end = start + int(1.5 * len(reference))
        else:
            start = max(0, end - int(1.5 * len(reference)))

        haystack = seq[start:end]
        if len(haystack) == 0:
            return None

        needle = reference.seq
        alignments = self._aligner.align(haystack, needle)
        try:
            if len(alignments) == 0:
                return None
        except OverflowError:
            pass

        alignment = alignments[0]
        coords = alignment.coordinates[0]
        alg_start, alg_end = int(coords[0]), int(coords[-1])

        counts = alignment.counts()
        if counts.identities / (alg_end - alg_start) >= 0.8 and counts.identities > 0.1 * len(reference):
            return Feature(start + alg_start, start + alg_end, seq, reference.name, reference.color)
        return None



class RdnaUnitFinder:
    def __init__(self, reference: Rdna, k: int):
        self.reference = reference
        self.k = k

        self._gene45sfinder = Gene45sFinder(self.reference, self.k)
        self._extender = RdnaExtender(self.reference, self.k)

    def find(self, seq: Seq) -> list[Rdna]:
        genes45s = self._gene45sfinder.find(seq)
        units = self._extender.extend(genes45s)
        return units


class RdnaExtender:
    def __init__(self, reference: Rdna, k: int):
        self.reference = reference
        self._suffix = self.reference.seq[self.reference.gene45s.end:]
        self._prefix = self.reference.seq[:self.reference.gene45s.start]
        self.k = k

        self._index = KmerIndex(self.reference.seq, self.k)
        self._prefix_idx = KmerIndex(self._prefix, self.k)
        self._suffix_idx = KmerIndex(self._suffix, self.k)
        self._aligner = PairwiseAligner(scoring="blastn", mode='local')

    def is_rising(window):
        if len(window) <= 1:
            return True
        increases = sum(1 for i in range(len(window)-1) if window[i] <= window[i+1])
        return increases / (len(window) - 1) >= 0.5


    def extend_right(self, unit: Rdna):
        void_counter = 0
        points = []
        window = []

        for i in range(unit.end, len(unit.base) - self.k):
            if void_counter > 2000 or i - unit.end > len(self.reference):
                break
            kmer = unit.base[i:i+self.k].seq
            if len(self._suffix_idx[kmer]) > 1:
                continue
            if len(self._suffix_idx[kmer]) == 0 or len(self._prefix_idx[kmer]) > 0 or "N" in kmer:
                void_counter += 1
                continue

            if void_counter > 0:
                void_counter -= 1
            if len(window) >= self.k:
                window.pop(0)

            window.append(self._suffix_idx[kmer][0])
            points.append((i - unit.end, self._suffix_idx[kmer][0]))

            if not RdnaExtender.is_rising(window):
                break

        best = unit.end
        close_points = self._filter_by_regression(points)
        if len(close_points):
            best = max(close_points, key=lambda x: x[0] + x[1])
            best = unit.end + int(best[0])

        best_in_ref = 0
        for i in range(best, best - 1000, -1):
            kmer = unit.base[i:i + self.k].seq
            if len(self._suffix_idx[kmer]) == 1 and len(self._prefix_idx[kmer]) == 0:
                best_in_ref = max(best_in_ref, self._suffix_idx[kmer][0])

        missing = self._suffix[best_in_ref:]
        if len(missing) < 2000:
            best_in_ref -= 2000 - len(missing)
        haystack = unit.base[best:best + int(1.5 * len(missing))]
        alignments = self._aligner.align(haystack, missing)
        alignment = alignments[0]

        counts = alignment.counts()
        if not (counts.identities + counts.gaps < 0.8 * len(missing)):
            coordinates = alignment.coordinates[0]
            end = best + int(coordinates[-1])
            best = end

        unit.igs = Igs(unit.end, best, unit.base)
        unit.igs.color = self.reference.igs.color
        unit.end = best

    def _filter_by_regression(self, points: list[tuple[int, int]]) -> list[tuple[int, int]]:
        if not points:
            return []

        points = np.asarray(points)
        rel = points[:, 0]
        ref = points[:, 1]

        X = np.column_stack([rel, np.ones(len(rel))])
        y = ref.reshape(-1, 1)
        beta = np.linalg.pinv(X.T @ X) @ (X.T @ y)
        y_pred = (X @ beta).flatten()

        residuals = np.abs(ref - y_pred)
        threshold = residuals.std()
        return points[residuals <= threshold]

    def extend_left(self, unit: Rdna) -> None:
        start = max(0, unit.start - round(1.8 * len(self._prefix)))
        alignment = self._aligner.align(unit.base[start:unit.start], self._prefix)[0]
        counts = alignment.counts()
        total_counts = (counts.identities + counts.gaps - counts.deletions + counts.mismatches)
        if counts.identities < 0.8 * total_counts or counts.aligned < 0.1 * len(self._prefix):
            return

        coordinates = alignment.coordinates[0]
        unit.start = start + int(coordinates[0])


    def extend(self, genes: list[Gene45s]) -> list[Rdna]:
        result = []
        for gene in genes:
            rdna = Rdna(gene)
            rdna.color = self.reference.color
            self.extend_right(rdna)
            self.extend_left(rdna)
            result.append(rdna)
        return result


class PartialUnitFinder:
    WINDOW = 500
    def __init__(self, reference: Rdna):
        self.reference = reference
        self._aligner = PairwiseAligner(scoring="blastn", mode='local')

    def find(self, seq: Seq, found: list[Interval]) -> list[IncompleteRdna]:
        base = Interval(0, len(seq))
        haystacks = Interval.complement(base, found)
        result = []

        result.extend(self._find_direction(seq, haystacks, True))
        result.extend(self._find_direction(seq, haystacks, False))
        return self._resolve_conflicts(result)

    def _find_direction(self, seq: Seq, haystacks: list[Interval], prefix: bool) -> list[IncompleteRdna]:
        if prefix:
            needle = self.reference.seq[:self.reference.igs.start]
            needle_offset = 0
        else:
            needle = self.reference.seq[self.reference.gene45s.start:]
            needle_offset = self.reference.gene45s.start

        result = []
        for haystack in haystacks:
            part = seq[haystack.start:haystack.end]
            finder = MinimapFinder(part)
            hits = finder.find(needle)
            intervals = self._extend_hits(part, self.reference.seq, needle_offset, hits)

            for interval in intervals:
                if len(interval) > 0.05 * len(self.reference):
                    result.append(IncompleteRdna(haystack.start + interval.start, haystack.start + interval.end, seq, prefix))
        return result

    def _resolve_conflicts(self, units: list[IncompleteRdna]) -> list[IncompleteRdna]:
        keep = [True] * len(units)
        for i, outer in enumerate(units):
            if not keep[i]:
                continue
            for j, inner in enumerate(units):
                if i == j or not keep[j]:
                    continue
                if outer.prefix == inner.prefix: 
                    # we don't want to resolve 2 suffixes or prefixes because 
                    # they should be merged instead to form longer block 
                    continue
                if outer.start <= inner.start and inner.end <= outer.end and len(outer) >= len(inner):
                    keep[j] = False

        result = [unit for unit, keep_unit in zip(units, keep) if keep_unit]
        return result

    def _extend_hits(self, haystack: Seq, seq: Seq, needle_offset: int, hits) -> list[Interval]:
        intervals = []
        for hit in hits:
            s = self._refine_boundary(haystack, seq, needle_offset, hit, True)
            e = self._refine_boundary(haystack, seq, needle_offset, hit, False)
            intervals.append(Interval(s, e))
        return Interval.merge(intervals)

    def _refine_boundary(self, haystack: Seq, seq: Seq, needle_offset: int, hit, front = True) -> int:
        if front:
            haystack = haystack[max(0, hit.r_st - self.WINDOW // 2) : hit.r_st + self.WINDOW // 2]
            n_start = max(0, needle_offset + hit.q_st - self.WINDOW // 2)
            n_end = needle_offset + hit.q_st + self.WINDOW // 2
            needle = seq[n_start : n_end]
        else:
            haystack = haystack[max(0, hit.r_en - self.WINDOW // 2) : hit.r_en + self.WINDOW // 2]
            n_start = max(0, needle_offset + hit.q_en - self.WINDOW // 2)
            n_end = needle_offset + hit.q_en + self.WINDOW // 2
            needle = seq[n_start:n_end]

        alignment = self._aligner.align(haystack.seq, needle.seq)
        if len(alignment) == 0:
            return None
        alignment = alignment[0]
        counts = alignment.counts()
        total_counts = (counts.identities + counts.gaps - counts.deletions + counts.mismatches)
        if counts.identities < 0.8 * total_counts or counts.aligned < 0.1 * len(needle):
            return hit.r_st if front else hit.r_en

        coordinates = alignment.coordinates[0]
        if front:
            return max(0, hit.r_st - self.WINDOW // 2) + int(coordinates[0])
        return max(0, hit.r_en - self.WINDOW // 2) + int(coordinates[-1])


class MinimapFinder:
    def __init__(self, haystack: Seq):
        self.aligner = mappy.Aligner(seq=str(haystack.seq), preset="asm5")
        self.haystack = haystack
        self.pairwise_aligner = PairwiseAligner(scoring="blastn", mode='local')
        

    def find(self, needle: Seq) -> list[Feature]:
        seq = needle
        result = []
        for hit in self.aligner.map(str(seq.seq)):
            if hit.strand > 0:
                result.append(hit)
        return result
