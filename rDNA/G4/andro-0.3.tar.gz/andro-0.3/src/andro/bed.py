from .rdna import Feature, Rdna, IncompleteRdna


class RdnaBedPrinter:
    FEATURE_LEVEL = {
        "RDNA": 0,
            "spacer_promoter": 1,
            "upstream_control_element": 1,
            "main_promoter": 1,
            "45S": 1,
                "5_ETS": 2,
                "18S": 2,
                "ITS1": 2,
                "5.8S": 2,
                "ITS2": 2,
                "28S": 2,
                "3_ETS": 2,
            "IGS": 1,
                "TR": 2,
                "LR": 2,
                    "CT_sat": 3,
            "TTF1": 1,
    }

    def __init__(self, output):
        self.output = output

    def _rgb(hex: str):
        hex = hex.lstrip('#')
        if len(hex) != 6:
            raise ValueError("Hex value must be 6 characters long.")
        return f"{int(hex[0:2], 16)},{int(hex[2:4], 16)},{int(hex[4:6], 16)}"

    def _print_feature(self, feature, incomplete):
        suffix = "_inc" if incomplete else ""
        f = feature
        if feature is not None:
            print(f.base.name, f.start, f.end, f.name + suffix, 0, ".", f.start, f.end, RdnaBedPrinter._rgb(f.color), sep="\t", file=self.output)

    def _feature_rank(self, feature: Feature) -> int:
        return self.FEATURE_LEVEL.get(feature.name, float('inf'))

    def _sorted_features(self, rdna: Rdna | IncompleteRdna) -> list[Feature]:
        features = [rdna]
        features.extend([
            rdna.spacer_promoter,
            rdna.upstream_control_element,
            rdna.main_promoter,
        ])

        if rdna.gene45s is not None:
            features.extend([
                rdna.gene45s,
                rdna.gene45s.ets5,
                rdna.gene45s.gene18s,
                rdna.gene45s.its1,
                rdna.gene45s.gene58s,
                rdna.gene45s.its2,
                rdna.gene45s.gene28s,
                rdna.gene45s.ets3,
            ])

        features.extend(rdna.others)

        if rdna.igs is not None:
            features.append(rdna.igs)
            features.extend(rdna.igs.tr or [])
            for lr in rdna.igs.lr or []:
                features.append(lr)
                features.append(lr.sat)

        filtered = [feature for feature in features if feature is not None]
        filtered.sort(key=lambda feature: (feature.start, -len(feature), self._feature_rank(feature), feature.name))
        return filtered

    def process(self, rdna: Rdna | IncompleteRdna) -> None:
        incomplete = isinstance(rdna, IncompleteRdna)
        for feature in self._sorted_features(rdna):
            self._print_feature(feature, incomplete)
