from typing import Union, Dict, List, Iterator, Tuple
from Bio.Seq import Seq
from Bio.SeqRecord import SeqRecord

class KmerIndex:
    """
    A k-mer index built over a Bio.Seq or SeqRecord.
    """
    def __init__(
        self,
        sequence: Union[str, Seq, SeqRecord],
        k: int,
    ) -> None:
        if isinstance(sequence, SeqRecord):
            seq = sequence.seq
        elif isinstance(sequence, Seq):
            seq = sequence
        elif isinstance(sequence, str):
            seq = Seq(sequence)
        else:
            raise TypeError("Sequence should be string, Seq or SeqRecord")

        if k <= 0:
            raise ValueError("kmer size must be positive")

        self.seq = seq
        self.k: int = k
        self._index: Dict[Seq, List[int]] = {}
        self._build()

    def _build(self) -> None:
        for i in range(len(self.seq) - self.k + 1):
            kmer = self.seq[i:i + self.k]
            if "N" not in kmer:
                self._index.setdefault(kmer, []).append(i)

    def __getitem__(self, kmer: Union[str, Seq]) -> List[int]:
        if isinstance(kmer, str):
            kmer = Seq(kmer)
        return list(self._index.get(kmer, []))

    def __contains__(self, kmer: Union[str, Seq]) -> bool:
        if isinstance(kmer, str):
            kmer = Seq(kmer)
        return kmer in self._index

    def __len__(self) -> int:
        return len(self._index)

    def __iter__(self) -> Iterator[Seq]:
        return iter(self._index)

    def items(self) -> Iterator[Tuple[Seq, List[int]]]:
        return self._index.items()

    def kmers(self) -> Iterator[Seq]:
        return self._index.keys()

    def positions(self) -> Iterator[List[int]]:
        return self._index.values()

    def as_dict(self) -> Dict[Seq, List[int]]:
        """Get the underlying index dict (keys are Seq)."""
        return self._index


class Interval:
    def __init__(self, start: int, end: int):
        self._start = min(start, end)
        self._end = max(start, end)

    def __len__(self):
        return abs(self._start - self._end)

    @property
    def start(self) -> int:
        return self._start

    @start.setter
    def start(self, value: int):
        self._start = value

    @property
    def end(self) -> int:
        return self._end

    @end.setter
    def end(self, value: int):
        self._end = value

    @property
    def mid(self) -> int:
        return (self._start + self._end) // 2

    def __lt__(self, other: "Interval") -> bool:
        if not isinstance(other, Interval):
            return False

        if self.start != other.start:
            return self.start < other.start
        return self.end < other.end

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Interval):
            return False
        return (self.start, self.end) == (other.start, other.end)

    def __iadd__(self, other: int):
        if isinstance(other, int):
            self._start += other
            self._end += other
            return self
        return NotImplemented

    def merge(intervals: list["Interval"]) -> list["Interval"]:
        if intervals == []:
            return []
        intervals = sorted(intervals)
        result = [intervals[0]]

        for i in range(1, len(intervals)):
            last = result[-1]

            if intervals[i].start <= last.end:
                last.end = max(last.end, intervals[i].end)
            else:
                result.append(intervals[i])

        return result
    
    def complement(segment: "Interval", intervals: list["Interval"]) -> list["Interval"]:
        covered = []
        for interval in intervals:
            start = max(segment.start, interval.start)
            end = min(segment.end, interval.end)
            covered.append(Interval(start, end))

        if not covered:
            return [Interval(segment.start, segment.end)]

        covered = Interval.merge(covered)
        result = []
        cursor = segment.start

        for interval in covered:
            if cursor < interval.start:
                result.append(Interval(cursor, interval.start))
            cursor = max(cursor, interval.end)

        if cursor < segment.end:
            result.append(Interval(cursor, segment.end))

        return result
