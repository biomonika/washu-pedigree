from .sequtils import Interval

class Feature(Interval):
    def __init__(self, start, end, seq, name="", color="#000000"):
        super().__init__(start, end)
        self.name = name
        self.base = seq
        self.color = color

    @property
    def seq(self):
        return self.base[self.start:self.end]


class Gene45s(Feature):
    def __init__(self, ets5, gene18s, gene58s, gene28s, ets3):
        self.ets5 = ets5
        self.gene18s = gene18s
        self.gene58s = gene58s
        self.gene28s = gene28s
        self.ets3 = ets3
        super().__init__(ets5.start, ets3.end, gene58s.base, "45S")
        self.its1 = Feature(gene18s.end, gene58s.start, self.base, "ITS1")
        self.its2 = Feature(gene58s.end, gene28s.start, self.base, "ITS2")


class LR(Feature):
    def __init__(self, feature: Feature, sat_feature: Feature = None):
        super().__init__(feature.start, feature.end, feature.base, "LR", feature.color)
        self.sat: Feature = sat_feature

class TR(Feature):
    def __init__(self, feature: Feature):
        super().__init__(feature.start, feature.end, feature.base, "TR", feature.color)


class Igs(Feature):
    def __init__(self, start, end, seq):
        super().__init__(start, end, seq, "IGS")
        self.tr: list[Feature] = []
        self.lr: list[LR] = []


class Rdna(Feature):
    def __init__(self, gene45s: Gene45s):
        self.gene45s: Gene45s = gene45s
        self.igs: Igs = None
        self.spacer_promoter: Feature = None
        self.upstream_control_element: Feature = None
        self.main_promoter: Feature = None
        self.others: list[Feature] = []
        super().__init__(gene45s.start, gene45s.end, gene45s.base, "RDNA")


class IncompleteRdna(Feature):
    def __init__(self, start, end, seq, prefix):
        super().__init__(start, end, seq, "RDNA")
        self.prefix = prefix

        self.spacer_promoter: Feature = None
        self.upstream_control_element: Feature = None
        self.main_promoter: Feature = None

        self.gene45s: IncompleteGene45s = None

        self.igs: Igs = None
        self.others: list[Feature] = []

class IncompleteGene45s(Feature):
    def __init__(self, start, end, seq):
        super().__init__(start, end, seq, "45S")
        self.ets5 = None
        self.gene18s = None
        self.its1 = None
        self.gene58s = None
        self.its2 = None
        self.gene28s = None
        self.ets3 = None
