import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SRC_DIR = PROJECT_ROOT / "src"
DATA_DIR = PROJECT_ROOT / "tests" / "data"
GOLDEN_DIR = PROJECT_ROOT / "tests" / "golden"


class CliGoldenRegressionTest(unittest.TestCase):
    def test_ky962518_rot_output_contains_golden_lines(self):
        self._assert_output_contains_golden_lines("KY962518-ROT.fa", "KY962518-ROT.bed")

    def test_hg_chr14_windows_output_contains_golden_lines(self):
        self._assert_output_contains_golden_lines("hg.chr14.windows.fasta", "hg.chr14.windows.bed")

    def _assert_output_contains_golden_lines(self, input_name: str, golden_name: str) -> None:
        input_path = DATA_DIR / input_name
        golden_path = GOLDEN_DIR / golden_name
        pythonpath = os.environ.get("PYTHONPATH")
        pythonpath = str(SRC_DIR) if not pythonpath else os.pathsep.join([str(SRC_DIR), pythonpath])

        with tempfile.TemporaryDirectory() as tmpdir:
            output_path = Path(tmpdir) / "output.bed"
            result = subprocess.run(
                [
                    sys.executable,
                    "-m",
                    "andro",
                    str(input_path),
                    "-o",
                    str(output_path),
                ],
                cwd=PROJECT_ROOT,
                text=True,
                capture_output=True,
                env={
                    **os.environ,
                    "PYTHONPATH": pythonpath,
                },
            )

            self.assertEqual(0, result.returncode)

            actual_lines = {
                line
                for line in output_path.read_text().splitlines()
                if line.strip()
            }
            expected_lines = [
                line
                for line in golden_path.read_text().splitlines()
                if line.strip()
            ]

            missing = [line for line in expected_lines if line not in actual_lines]
            self.assertEqual(
                [],
                missing,
                msg="output is missing golden lines:\n" + "\n".join(missing),
            )
