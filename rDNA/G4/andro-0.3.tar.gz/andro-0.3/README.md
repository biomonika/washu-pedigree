# andro

`andro` is a small reference-guided CLI tool for finding and annotating human rDNA units in FASTA sequences.

It is built around the `KY962518-ROT` reference and reports annotations in BED format. It can also generate dotplots for detected units.

## Installation

```bash
pip install andro
```

## Basic usage
Simply call `andro` with FASTA file as argument
```bash
andro example.fa
```

`andro` has several useful options, which can be displayed by
```bash
andro --help
```

## What It Does

Given file with one or more FASTA records, `andro` will:

- find rDNA units anchored by a detected 45S region
- extend the detected 45S to the full unit when possible
- annotate major rDNA features
- write annotations as BED
- optionally generate dotplots for each reported unit

## What Counts As rDNA By Default

By default, `andro` reports only units in which a full 45S region is found.

`andro` supports option `--partial` to report incomplete unit. `andro` will not report parts of unit that are shorter than aproximately 2500bp. Since `andro` was initially design for whole genome sequences and later was expanded for incomplte units this may lead to incomplete annotations or even
crash. Therefore annotation of incomplete units may be useful, but they should be treated as experimantal feature.

